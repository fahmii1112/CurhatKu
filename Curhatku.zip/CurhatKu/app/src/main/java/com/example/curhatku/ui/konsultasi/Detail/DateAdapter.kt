package com.example.curhatku.ui.konsultasi.Detail

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.R

class DateAdapter(
    private val dates: List<String>,
    private val onDateSelected: (String) -> Unit
) : RecyclerView.Adapter<DateAdapter.DateViewHolder>() {

    private var selectedPosition = -1

    inner class DateViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val buttonDate: Button = view.findViewById(R.id.buttonDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DateViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_date, parent, false)
        return DateViewHolder(view)
    }

    override fun onBindViewHolder(holder: DateViewHolder, position: Int) {
        val date = dates[position]
        holder.buttonDate.text = date

        // Tandai item terpilih
        holder.buttonDate.isSelected = position == selectedPosition

        holder.buttonDate.setOnClickListener {
            selectedPosition = position
            notifyDataSetChanged()
            onDateSelected(date)
        }
    }
    // Fungsi untuk mendapatkan tanggal yang dipilih
    fun getSelectedDate(): String? {
        return if (selectedPosition >= 0) dates[selectedPosition] else null
    }
    override fun getItemCount(): Int = dates.size
}