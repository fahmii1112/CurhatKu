package com.example.curhatku.model

data class SolusiResponse(
    val judul: String,
    val tanggal_diperbarui: String,
    val isi: IsiSolusi
)

data class IsiSolusi(
    val stres: String,
    val kecemasan: String,
    val depresi: String
)