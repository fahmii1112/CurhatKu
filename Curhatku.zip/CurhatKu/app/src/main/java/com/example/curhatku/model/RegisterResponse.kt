package com.example.curhatku.model

data class RegisterResponse(
    val success: Boolean,
    val message: String
)