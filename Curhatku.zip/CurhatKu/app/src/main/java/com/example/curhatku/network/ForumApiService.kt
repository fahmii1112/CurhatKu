package com.example.curhatku.network

import com.example.curhatku.model.DiskusiRequest
import com.example.curhatku.model.DiskusiResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ForumApiService {
    @POST("/diskusi")
    suspend fun createDiskusi(@Body diskusiRequest: DiskusiRequest): DiskusiResponse

    @GET("/diskusi")
    suspend fun getAllDiskusi(): List<DiskusiResponse>

}