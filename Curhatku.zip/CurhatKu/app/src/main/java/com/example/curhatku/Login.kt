package com.example.curhatku

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class Login : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: AppCompatButton
    private lateinit var togglePasswordVisibility: ImageButton

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        emailEditText = findViewById(R.id.email)
        passwordEditText = findViewById(R.id.password)
        loginButton = findViewById(R.id.button)
        togglePasswordVisibility = findViewById(R.id.togglePasswordVisibility)

        // ambil data
        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val storedEmail = sharedPreferences.getString("email", null) // Dapatkan email yang tersimpan
        val storedPassword = sharedPreferences.getString("password", null) // Dapatkan password yang tersimpan

        togglePasswordVisibility.setOnClickListener {
            if (passwordEditText.inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                passwordEditText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                togglePasswordVisibility.setImageResource(R.drawable.hide)
            } else {
                passwordEditText.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                togglePasswordVisibility.setImageResource(R.drawable.show)
            }
            // Pindahkan kursor ke akhir teks
            passwordEditText.setSelection(passwordEditText.text.length)
        }

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Cek tidak null
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Harap isi semua kolom!", Toast.LENGTH_SHORT).show()
            } else {
                // Cek
                if (email == storedEmail && password == storedPassword) {
                    // Login berhasil
                    Toast.makeText(this, "Login Berhasil!", Toast.LENGTH_SHORT).show()

                    // navigasi ke Activity
                    val intent = Intent(this, MainActivity ::class.java)
                    startActivity(intent)
                    finish() //
                } else {
                    Toast.makeText(this, "Email atau password salah!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

}