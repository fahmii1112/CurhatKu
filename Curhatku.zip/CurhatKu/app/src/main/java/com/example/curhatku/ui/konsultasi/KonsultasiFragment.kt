package com.example.curhatku.ui.konsultasi

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.curhatku.R
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.ui.konsultasi.Detail.DoctorDetailActivity

class KonsultasiFragment : Fragment() {

    private lateinit var doctorAdapter: DoctorAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate layout fragment_konsultasi.xml
        return inflater.inflate(R.layout.fragment_konsultasi, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Dummy data untuk dokter
        val dummyDoctors = listOf(
            Doctor(
                name = "A.D. Andriyanti, S.Psi., Psi",
                specialty = "Psikolog Klinis",
                hospitalLocation = "RS Mitra Keluarga Tegal, Kota Tegal",
                profileImage = R.drawable.doctor_women,
                price = "Rp 328.000"
            ),
            Doctor(
                name = "Agnes Dewanti Purnomowardani, Psi., M.Psi",
                specialty = "Psikolog Klinis",
                hospitalLocation = "Siloam Hospitals Yogyakarta, Kota Yogyakarta",
                profileImage = R.drawable.doctor_women,
                price = "Rp 350.000"
            ),
            Doctor(
                name = "Bambang Sutrisno, Sp.KJ",
                specialty = "Psikiater",
                hospitalLocation = "RS Dr. Sardjito, Kota Yogyakarta",
                profileImage = R.drawable.doctor,
                price = "Rp 300.000"
            )
        )

        // Setup adapter dengan RecyclerView
        doctorAdapter = DoctorAdapter(
            dummyDoctors,
            onItemClick = { doctor ->
                // Intent ke detail dokter
                val intent = Intent(requireContext(), DoctorDetailActivity::class.java)
                intent.putExtra("doctor_name", doctor.name)
                intent.putExtra("doctor_specialty", doctor.specialty)
                intent.putExtra("hospital_location", doctor.hospitalLocation)
                intent.putExtra("doctor_price", doctor.price)
                intent.putExtra("profile_image", doctor.profileImage) // Int untuk drawable
                startActivity(intent)
            },
            onButtonClick = { doctor ->
                // Logika untuk membuat janji
                Toast.makeText(
                    requireContext(),
                    "Buat Janji dengan ${doctor.name}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )

        // Atur RecyclerView
        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerViewDoctors)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = doctorAdapter
    }
}