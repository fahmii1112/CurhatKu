package com.example.curhatku.model

data class LoginRequest(
    val username: String,
    val password: String
)