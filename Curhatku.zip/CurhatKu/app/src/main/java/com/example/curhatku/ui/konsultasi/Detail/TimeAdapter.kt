package com.example.curhatku.ui.konsultasi.Detail

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.R

class TimeAdapter(
    private val times: List<String>,
    private val onTimeSelected: (String) -> Unit
) : RecyclerView.Adapter<TimeAdapter.TimeViewHolder>() {

    private var selectedPosition = -1 // Indeks tombol yang dipilih

    inner class TimeViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val buttonTime: Button = view.findViewById(R.id.buttonTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_time, parent, false)
        return TimeViewHolder(view)
    }

    override fun onBindViewHolder(holder: TimeViewHolder, position: Int) {
        val time = times[position]
        holder.buttonTime.text = time

        // Atur state `selected` berdasarkan posisi yang dipilih
        holder.buttonTime.isSelected = position == selectedPosition

        // Klik tombol untuk mengubah state
        holder.buttonTime.setOnClickListener {
            selectedPosition = position
            notifyDataSetChanged() // Refresh RecyclerView untuk update UI
            onTimeSelected(time)
        }

    }
    fun getSelectedTime(): String? {
        return if (selectedPosition >= 0) times[selectedPosition] else null
    }
    override fun getItemCount(): Int = times.size
}
