package com.example.curhatku

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class Intro : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro)
        val lanjutkanButton = findViewById<AppCompatButton>(R.id.button)

        lanjutkanButton.setOnClickListener {

            val intent = Intent(this, Register::class.java)
            startActivity(intent)
            finish()
        }

    }
}