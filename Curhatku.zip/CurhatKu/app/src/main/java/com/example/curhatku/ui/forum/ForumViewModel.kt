package com.example.curhatku.ui.forum

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.curhatku.model.PredictionRequest
import com.example.curhatku.model.PredictionResponse
import com.example.curhatku.network.RetrofitClient
import com.example.curhatku.ui.forum.detail.Comment
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

// Modifikasi ForumViewModel
class ForumViewModel(application: Application) : AndroidViewModel(application) {

    private val sharedPreferences = application.getSharedPreferences("ForumPrefs", Context.MODE_PRIVATE)

    private val _posts = MutableLiveData<List<Post>>(emptyList())
    val posts: LiveData<List<Post>> get() = _posts

    private val _comments = MutableLiveData<List<Comment>>(emptyList())
    val comments: LiveData<List<Comment>> = _comments

    private val _emotion = MutableLiveData<PredictionResponse?>()
    val emotion: LiveData<PredictionResponse?> = _emotion

    init {
        loadPosts()
    }

    fun addPost(post: Post) {
        val updatedPosts = _posts.value.orEmpty().toMutableList()
        updatedPosts.add(0, post)
        _posts.value = updatedPosts
        savePosts(updatedPosts)
    }

    fun removePost(post: Post) {
        val currentPosts = _posts.value ?: mutableListOf()
        val updatedPosts = currentPosts.toMutableList()
        if (updatedPosts.remove(post)) {
            _posts.value = updatedPosts
            savePosts(updatedPosts)
            Log.d("ForumViewModel", "Post removed successfully")
        } else {
            Log.e("ForumViewModel", "Failed to remove post: $post")
        }
    }

    private fun savePosts(posts: List<Post>) {
        val json = Gson().toJson(posts)
        sharedPreferences.edit().putString("posts", json).apply()
    }

    private fun loadPosts() {
        val json = sharedPreferences.getString("posts", null)
        if (json != null) {
            try {
                val savedPosts = Gson().fromJson(json, Array<Post>::class.java).toList()
                _posts.value = savedPosts
            } catch (e: Exception) {
                Log.e("ForumViewModel", "Failed to parse posts", e)
            }
        }
    }

    fun loadComments(name: String) {
        val json = sharedPreferences.getString("comments", null)

        if (json != null) {
            try {
                val savedDatumComments = Gson().fromJson(json, Array<Comment>::class.java).toList()

                val filteredComments = savedDatumComments.filter { it.postedBy == name }

                _comments.value = filteredComments
            } catch (e: Exception) {
                Log.e("ForumViewModel", "Failed to parse comment", e)
            }
        }
    }

    fun removeComment(comment: Comment) {
        val currentComments = _comments.value ?: mutableListOf()
        val updatedComments= currentComments.toMutableList()
        if (updatedComments.remove(comment)) {
            _comments.value = updatedComments
            saveComments(updatedComments)
            Log.d("ForumViewModel", "Comment removed successfully")
        } else {
            Log.e("ForumViewModel", "Failed to remove post: $comment")
        }
    }

    private fun saveComments(posts: List<Comment>) {
        val json = Gson().toJson(posts)
        sharedPreferences.edit().putString("comments", json).apply()
    }

    fun addComment(comment: Comment) {
        val updatedPosts = _comments.value.orEmpty().toMutableList()
        updatedPosts.add(0, comment)
        _comments.value = updatedPosts
        saveComments(updatedPosts)
    }


    fun predictEmotion(
        text: String
    ) {
        val request = PredictionRequest(text)
        val client = RetrofitClient.modelApiService.predictEmotion(request)
        client.enqueue(object : Callback<PredictionResponse> {
            override fun onResponse(
                call: Call<PredictionResponse>,
                response: Response<PredictionResponse>
            ) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    _emotion.postValue(responseBody)
                } else {
                    val errorMsg = response.message() ?: "Gagal mendeteksi"
                    Log.e(TAG, "onResponse: $errorMsg" )
                }
            }

            override fun onFailure(call: Call<PredictionResponse>, t: Throwable) {
                val errorMsg = t.message ?: "Unknown error occurred"
                Log.e(TAG, "onFailure: $errorMsg")
            }
        })
    }

    companion object {
        private const val TAG= "ForumViewModel"
    }
}
