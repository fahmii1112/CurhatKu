package com.example.curhatku.ui.forum.detail

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.LifecycleOwner
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.R
import com.example.curhatku.ui.forum.ForumViewModel

class CommentAdapter(
    private val posts: MutableList<Comment>,
    private val forumViewModel: ForumViewModel,
    private val lifecycleOwner: LifecycleOwner,

    ) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var isEditing = false

    private val TYPE_CREATE_POST = 1
    private val TYPE_VIEW_POST = 2

    inner class CreatePostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val editTextContent: EditText = itemView.findViewById(R.id.komen)
        val postButton: Button = itemView.findViewById(R.id.buttonPost)
    }

    inner class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val userName: TextView = itemView.findViewById(R.id.textUserName)
        val profileImage: ImageView = itemView.findViewById(R.id.imageViewProfile)
        val postTime: TextView = itemView.findViewById(R.id.textPostTime)
        val emotion: TextView = itemView.findViewById(R.id.emosi)
        val content: EditText = itemView.findViewById(R.id.editTextContent)
        val deleteButton: Button = itemView.findViewById(R.id.buttonPostingan)
        val editButton: Button = itemView.findViewById(R.id.buttonEdit)
        val saveButton: Button = itemView.findViewById(R.id.simpan)
    }

    override fun getItemViewType(position: Int): Int {
        return if (position == posts.size && isEditing) TYPE_CREATE_POST else TYPE_VIEW_POST
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_CREATE_POST) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.komen, parent, false)
            CreatePostViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.postingan, parent, false)
            PostViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is PostViewHolder -> {
                bindPostViewHolder(holder, position)
            }
            is CreatePostViewHolder -> bindCreatePostViewHolder(holder)
        }
    }


    private fun bindPostViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]

        // Set post details
        holder.userName.text = post.username
        holder.profileImage.setImageResource(post.profileImage)
        holder.postTime.text = post.postTime
        holder.content.setText(post.content)

        // Edit and save functionality
        holder.content.isEnabled = post.isEditable
        holder.saveButton.visibility = if (post.isEditable) View.VISIBLE else View.GONE

        holder.editButton.setOnClickListener {
            post.isEditable = true
            notifyItemChanged(position)
        }

        holder.saveButton.setOnClickListener {
            post.content = holder.content.text.toString()
            post.isEditable = false
            notifyItemChanged(position)
        }

        // Delete post
        holder.deleteButton.setOnClickListener {
            val postToDelete = posts[holder.adapterPosition]
            forumViewModel.removeComment(postToDelete)
            notifyItemRemoved(holder.adapterPosition)
        }
    }

    @SuppressLint("NotifyDataSetChanged", "SetTextI18n")
    private fun bindCreatePostViewHolder(holder: CreatePostViewHolder) {

        holder.postButton.setOnClickListener {
            val newContent = holder.editTextContent.text.toString()
            if (newContent.isNotEmpty()) {
                val newPost = Comment(
                    id = (posts.size + 1).toString(),
                    username = "User Comment",
                    profileImage = R.drawable.user,
                    content = newContent,
                    postTime = "Just now",
                    timestamp = System.currentTimeMillis(),
                    postedBy = "User Baru"
                )
                forumViewModel.addComment(newPost)
                isEditing = false
                notifyDataSetChanged()
                holder.editTextContent.text.clear()
            }
        }
    }

    override fun getItemCount(): Int = posts.size + if (isEditing) 1 else 0

    fun enableEditing() {
        isEditing = true
        notifyItemInserted(posts.size)
    }

    fun addPost(post: Comment) {
        posts.add(post)
        notifyDataSetChanged()
    }

    fun removePost(position: Int) {
        posts.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, posts.size)
    }

    fun updateComment(newPosts: List<Comment>) {
        posts.clear()
        posts.addAll(newPosts)
        notifyDataSetChanged()
    }
}