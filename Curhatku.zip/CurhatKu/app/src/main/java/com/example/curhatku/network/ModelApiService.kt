package com.example.curhatku.network

import com.example.curhatku.model.PredictionRequest
import com.example.curhatku.model.PredictionResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ModelApiService {
    @POST("predict")
    fun predictEmotion(@Body request: PredictionRequest): Call<PredictionResponse>
}