package com.example.curhatku.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    private const val BASE_URL = "https://api-infomation-92381090063.asia-southeast2.run.app/"
    private const val MODEL_BASE_URL = "https://api-model-curhatku-92381090063.asia-southeast2.run.app/"
    private const val FORUM_BASE_URL = "https://api-forum-92381090063.asia-southeast2.run.app/"

    private fun getRetrofitInstance(baseUrl: String): Retrofit {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val service: ApiService by lazy {
        getRetrofitInstance(BASE_URL).create(ApiService::class.java)
    }

    val modelApiService: ModelApiService by lazy {
        getRetrofitInstance(MODEL_BASE_URL).create(ModelApiService::class.java)
    }

    val forumApiService: ForumApiService by lazy {
        getRetrofitInstance(FORUM_BASE_URL).create(ForumApiService::class.java)
    }
}
