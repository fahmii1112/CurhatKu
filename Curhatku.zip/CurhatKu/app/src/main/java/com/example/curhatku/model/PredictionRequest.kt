package com.example.curhatku.model

import com.google.gson.annotations.SerializedName

data class PredictionRequest(

	@field:SerializedName("text")
	val text: String? = null
)
