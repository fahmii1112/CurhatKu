package com.example.curhatku.ui.home

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.R
import com.example.curhatku.RsAdapter

class HomeFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var userGreeting: TextView
    private lateinit var homeViewModel: HomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (requireActivity() as AppCompatActivity).supportActionBar?.setDisplayShowTitleEnabled(false)

        // Inisialisasi RecyclerView
        recyclerView = view.findViewById(R.id.view1)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Inisialisasi ViewModel
        homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)

        // Observe data dari ViewModel
        homeViewModel.hospitalList.observe(viewLifecycleOwner) { hospitalList ->
            val adapter = RsAdapter(hospitalList) { selectedItem ->
                Toast.makeText(requireContext(), "Anda memilih: $selectedItem", Toast.LENGTH_SHORT).show()
                //Navigasi ke detail, jika diperlukan
            }
            recyclerView.adapter = adapter
        }

        // Set greeting
        userGreeting = view.findViewById(R.id.textView3)
        val sharedPreferences =
            requireContext().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val nama = sharedPreferences.getString("nama", "User")
        userGreeting.text = "Hi, $nama"
// Menambahkan tombol dan OnClickListener
        val buttonInformasi = view.findViewById<Button>(R.id.buttonInformasi)
        val buttonForum = view.findViewById<Button>(R.id.buttonForum)
        val buttonEmergency = view.findViewById<Button>(R.id.buttonEmergency)

        buttonInformasi.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_informasi)
            // Menampilkan pesan Toast saat tombol diklik
            Toast.makeText(requireContext(), "Tombol Informasi Diklik", Toast.LENGTH_SHORT).show()

        }

        buttonForum.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_forum)
            // Menampilkan pesan Toast saat tombol diklik
            Toast.makeText(requireContext(), "Tombol Forum Diklik", Toast.LENGTH_SHORT).show()

        }

        buttonEmergency.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_emergencyCall)
            // Menampilkan pesan Toast saat tombol diklik
            Toast.makeText(requireContext(), "Tombol Emergency Call Diklik", Toast.LENGTH_SHORT).show()

        }

    }
}