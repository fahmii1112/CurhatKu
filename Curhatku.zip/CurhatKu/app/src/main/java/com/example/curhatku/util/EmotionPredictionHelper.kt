package com.example.curhatku.util

import android.content.Context
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import android.util.Log
import com.google.gson.Gson

class EmotionPredictionHelper(context: Context, modelPath: String) {
    private val interpreter: Interpreter
    val gson: Gson = Gson()

    init {
        try {
            val assetFileDescriptor = context.assets.openFd(modelPath)
            val fileInputStream = assetFileDescriptor.createInputStream()
            val fileChannel = fileInputStream.channel
            val startOffset = assetFileDescriptor.startOffset
            val declaredLength = assetFileDescriptor.declaredLength
            val byteBuffer = fileChannel.map(java.nio.channels.FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
            interpreter = Interpreter(byteBuffer)
        } catch (e: Exception) {
            e.printStackTrace()
            throw RuntimeException("Error loading model", e)
        }
    }

    fun predictEmotion(inputText: String): String {
        try {
            // Preprocessing input (dummy: gunakan panjang teks)
            val inputBuffer = preprocessText(inputText)

            // Allocate output buffer
            val outputBuffer = TensorBuffer.createFixedSize(intArrayOf(1, NUM_CLASSES), DataType.FLOAT32)

            // Run inference
            interpreter.run(inputBuffer, outputBuffer.buffer)

            // Post-process output
            return postProcessOutput(outputBuffer.floatArray)
        } catch (e: Exception) {
            Log.e("EmotionPrediction", "Error during prediction", e)
            return "Kesalahan dalam prediksi"
        }
    }

    private fun preprocessText(text: String): ByteBuffer {
        // Dummy preprocessing: hanya panjang teks
        val buffer = ByteBuffer.allocateDirect(INPUT_SIZE).order(ByteOrder.nativeOrder())
        buffer.putFloat(text.length.toFloat()) // Menggunakan panjang teks sebagai input dummy
        return buffer
    }

    private fun postProcessOutput(output: FloatArray): String {
        // Menampilkan output untuk debugging
        Log.d("EmotionPrediction", "Model output: ${output.joinToString(", ")}")

        val emotions = listOf("terkejut", "percaya", "sedih", "senang", "takut", "jijik", "marah", "waspada")
        val maxIndex = output.indices.maxByOrNull { output[it] } ?: -1
        return if (maxIndex != -1) emotions[maxIndex] else "Emosi tidak dikenal"
    }

    companion object {
        private const val NUM_CLASSES = 8 // Jumlah kelas emosi
        private const val INPUT_SIZE = 4  // Ukuran input, sesuai dengan model
    }
}
