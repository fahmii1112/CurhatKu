package com.example.curhatku.ui.konsultasi

data class Doctor(
    val name: String,
    val specialty: String,
    val hospitalLocation: String,
    val profileImage: Int,
    val price: String
)