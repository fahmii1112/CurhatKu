package com.example.curhatku.model

data class DiskusiResponse(
    val id: String,
    val judul: String,
    val isi: String
)