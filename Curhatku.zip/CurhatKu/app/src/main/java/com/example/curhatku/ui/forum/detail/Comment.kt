package com.example.curhatku.ui.forum.detail

data class Comment(
    val id: String,
    val username: String,
    val profileImage: Int,
    var content: String,
    val postTime: String,
    val timestamp: Long = System.currentTimeMillis(),
    var isEditable: Boolean = false,
    val postedBy: String
)