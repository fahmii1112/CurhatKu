package com.example.curhatku.ui.forum

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.R
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ForumFragment : Fragment() {
    private lateinit var postAdapter: PostAdapter
    private val forumViewModel: ForumViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_forum, container, false)

        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerViewPosts)
        val fabCreatePost: FloatingActionButton = view.findViewById(R.id.fabCreatePost)

        // Setup RecyclerView
        postAdapter = PostAdapter(mutableListOf(), forumViewModel, viewLifecycleOwner)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = postAdapter

        // Observe LiveData dari ViewModel
        forumViewModel.posts.observe(viewLifecycleOwner) { updatedPosts ->
            postAdapter.updatePosts(updatedPosts)
        }

        // Action untuk FAB
        fabCreatePost.setOnClickListener {
            postAdapter.enableEditing()
            recyclerView.scrollToPosition(postAdapter.itemCount - 1)
        }

        return view
    }
}
