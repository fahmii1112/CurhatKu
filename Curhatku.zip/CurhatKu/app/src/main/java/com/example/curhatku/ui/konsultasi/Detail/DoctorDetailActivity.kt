package com.example.curhatku.ui.konsultasi.Detail

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.R
import com.example.curhatku.ui.janji.Appointment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class DoctorDetailActivity : AppCompatActivity() {

    private lateinit var dateAdapter: DateAdapter
    private lateinit var timeAdapter: TimeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_detail)

        // Ambil data dari intent
        val doctorName = intent.getStringExtra("doctor_name")
        val doctorSpecialty = intent.getStringExtra("doctor_specialty")
        val hospitalLocation = intent.getStringExtra("hospital_location")
        val consultationPrice = intent.getStringExtra("doctor_price")
        val profileImage = intent.getIntExtra("profile_image", R.drawable.default_doctor)

        // Bind data ke tampilan
        findViewById<TextView>(R.id.textDoctorName).text = doctorName
        findViewById<TextView>(R.id.textDoctorSpecialty).text = doctorSpecialty
        findViewById<TextView>(R.id.textHospitalLocation).text = hospitalLocation
        findViewById<TextView>(R.id.textConsultationPrice).text = consultationPrice

        // Set image dari drawable
        val imageView = findViewById<ImageView>(R.id.imageDoctor)
        imageView.setImageResource(profileImage)

        // Data jadwal untuk setiap dokter
        val doctorSchedules = mapOf(
            "A.D. Andriyanti, S.Psi., Psi" to Pair(
                listOf("Besok 5 Dec", "Senin 9 Dec", "Kamis 12 Dec"),
                listOf("16:00", "16:30", "17:00", "17:30")
            ),
            "Agnes Dewanti Purnomowardani, Psi., M.Psi" to Pair(
                listOf("Selasa 6 Dec", "Rabu 10 Dec", "Jumat 13 Dec"),
                listOf("09:00", "09:30", "10:00", "10:30")
            ),
            "Bambang Sutrisno, Sp.KJ" to Pair(
                listOf("Sabtu 7 Dec", "Minggu 11 Dec", "Senin 14 Dec"),
                listOf("14:00", "14:30", "15:00", "15:30")
            )
        )

        // Ambil jadwal berdasarkan nama dokter
        val schedule = doctorSchedules[doctorName]
        val dates = schedule?.first ?: emptyList()
        val times = schedule?.second ?: emptyList()

        // Atur RecyclerView untuk jadwal tanggal
        dateAdapter = DateAdapter(dates) { selectedDate ->
            Toast.makeText(this, "Tanggal dipilih: $selectedDate", Toast.LENGTH_SHORT).show()
        }

        findViewById<RecyclerView>(R.id.recyclerViewDates).apply {
            layoutManager = GridLayoutManager(this@DoctorDetailActivity, 3) // 3 kolom untuk tanggal
            adapter = dateAdapter
        }

        // Atur RecyclerView untuk jadwal waktu
        timeAdapter = TimeAdapter(times) { selectedTime ->
            Toast.makeText(this, "Waktu dipilih: $selectedTime", Toast.LENGTH_SHORT).show()
        }

        findViewById<RecyclerView>(R.id.recyclerViewTimes).apply {
            layoutManager = GridLayoutManager(this@DoctorDetailActivity, 4) // 4 kolom untuk waktu
            adapter = timeAdapter
        }

        // Tambahkan aksi untuk tombol Buat Janji
        findViewById<Button>(R.id.buttonMakeAppointment).setOnClickListener {
            val selectedDate = dateAdapter.getSelectedDate()
            val selectedTime = timeAdapter.getSelectedTime()

            if (selectedDate == null || selectedTime == null) {
                Toast.makeText(this, "Pilih tanggal dan waktu terlebih dahulu!", Toast.LENGTH_SHORT).show()
            } else {
                val appointment = Appointment(
                    name = doctorName ?: "",
                    specialty = doctorSpecialty ?: "",
                    hospitalLocation = hospitalLocation ?: "",
                    profileImage = profileImage,
                    price = consultationPrice ?: "",
                    date = selectedDate,
                    time = selectedTime
                )

                // Simpan appointment ke SharedPreferences
                saveAppointment(appointment)

                Toast.makeText(
                    this,
                    "Janji dibuat: $selectedDate, $selectedTime untuk ${appointment.name}",
                    Toast.LENGTH_SHORT
                ).show()

                finish()
            }
        }
    }

    // Fungsi untuk menyimpan data janji ke SharedPreferences
    private fun saveAppointment(appointment: Appointment) {
        val sharedPreferences = getSharedPreferences("Appointments", Context.MODE_PRIVATE)
        val gson = Gson()

        // Ambil data janji yang sudah ada
        val json = sharedPreferences.getString("saved_appointments", "[]")
        val type = object : TypeToken<MutableList<Appointment>>() {}.type
        val appointmentList: MutableList<Appointment> = gson.fromJson(json, type)

        // Tambahkan janji baru ke dalam daftar
        appointmentList.add(appointment)

        // Simpan kembali ke SharedPreferences
        val editor = sharedPreferences.edit()
        editor.putString("saved_appointments", gson.toJson(appointmentList))
        editor.apply()
    }
}
