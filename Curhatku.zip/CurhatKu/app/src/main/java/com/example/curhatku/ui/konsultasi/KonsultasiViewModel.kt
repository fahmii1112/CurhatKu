package com.example.curhatku.ui.konsultasi

import androidx.lifecycle.ViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.curhatku.R

class KonsultasiViewModel : ViewModel() {
    private val _doctors = MutableLiveData<List<Doctor>>()
    val doctors: LiveData<List<Doctor>> get() = _doctors

    init {
        loadDoctors()
    }

    private fun loadDoctors() {
        // Data dummy untuk testing, ini bisa diganti dengan pengambilan data dari API
        val dummyDoctors = listOf(
            Doctor(
                name = "A.D. Andriyanti, S.Psi., Psi",
                specialty = "Psikolog Klinis",
                hospitalLocation = "RS Mitra Keluarga Tegal, Kota Tegal",
                profileImage = R.drawable.doctor_women,
                price = "Rp 328.000"
            ),
            Doctor(
                name = "Agnes Dewanti Purnomowardani, Psi., M.Psi",
                specialty = "Psikolog Klinis",
                hospitalLocation = "Siloam Hospitals Yogyakarta, Kota Yogyakarta",
                profileImage = R.drawable.doctor_women,
                price = "Rp 350.000"
            ),
            Doctor(
                name = "Bambang Sutrisno, Sp.KJ",
                specialty = "Psikiater",
                hospitalLocation = "RS Dr. Sardjito, Kota Yogyakarta",
                profileImage = R.drawable.doctor,
                price = "Rp 300.000"
            )
        )
        _doctors.value = dummyDoctors
    }
}