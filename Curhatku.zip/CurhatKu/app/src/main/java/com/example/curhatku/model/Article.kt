package com.example.curhatku.model

data class Article(
    val title: String,
    val summary: String,
    val content: String
)