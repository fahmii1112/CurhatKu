package com.example.curhatku.model

data class LoginResponse(
    val token: String,
    val userId: String
)