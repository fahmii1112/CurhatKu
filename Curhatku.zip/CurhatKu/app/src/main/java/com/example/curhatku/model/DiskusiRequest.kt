package com.example.curhatku.model

data class DiskusiRequest(
    val judul: String,
    val isi: String,
    val userId: String
)