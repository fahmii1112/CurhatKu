package com.example.curhatku.ui.forum.detail

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.R
import com.example.curhatku.ui.forum.ForumViewModel
import com.example.curhatku.ui.forum.PostAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ActivityDetailForum : AppCompatActivity() {
    private val forumViewModel: ForumViewModel by viewModels()
    private lateinit var commentAdapter: CommentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detail_forum)

        val name = intent.getStringExtra("name")
        val emotion = intent.getStringExtra("emotion")
        val masalah = intent.getStringExtra("masalah")

        val textUserName = findViewById<TextView>(R.id.textUserName)
        val emosi = findViewById<TextView>(R.id.emosi)
        val edContent = findViewById<EditText>(R.id.editTextContent)

        forumViewModel.loadComments(name.toString())

        textUserName.text = name
        emosi.text = emotion
        edContent.setText(masalah)
        edContent.isEnabled = false

        val recyclerView: RecyclerView = findViewById(R.id.recyclerViewkomen)
        val fabCreatePost: FloatingActionButton = findViewById(R.id.komen)

        // Setup RecyclerView
        commentAdapter = CommentAdapter(mutableListOf(), forumViewModel, this)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = commentAdapter

        // Observe LiveData dari ViewModel
        forumViewModel.comments.observe(this) { comments ->
            commentAdapter.updateComment(comments)
        }

        // Action untuk FAB
        fabCreatePost.setOnClickListener {
            commentAdapter.enableEditing()
            recyclerView.scrollToPosition(commentAdapter.itemCount - 1)
        }
    }
}