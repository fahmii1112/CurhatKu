package com.example.curhatku.ui.forum

data class Post(
    val id: String,
    val username: String,
    val profileImage: Int,
    var content: String,
    val emotion: String,
    val postTime: String,
    val timestamp: Long = System.currentTimeMillis(),
    var isEditable: Boolean = false
)