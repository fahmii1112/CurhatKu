package com.example.curhatku.ui.janji.Detail

import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.curhatku.R
import com.example.curhatku.ui.janji.Appointment

class AppointmentDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_appointment_detail)

        // Menerima objek Appointment dari Intent
        val appointment = intent.getSerializableExtra("appointment") as? Appointment

        if (appointment != null) {
            Log.d("AppointmentDetailActivity", "Received appointment: $appointment")
            findViewById<TextView>(R.id.textDoctorName).text = appointment.name ?: "Unknown"
            findViewById<TextView>(R.id.textDoctorSpecialty).text = appointment.specialty ?: "Unknown"
            findViewById<TextView>(R.id.textHospitalLocation).text = appointment.hospitalLocation ?: "Unknown"
            findViewById<TextView>(R.id.textConsultationPrice).text = appointment.price ?: "N/A"
            findViewById<TextView>(R.id.textAppointmentDate).text = appointment.date ?: "N/A"
            findViewById<TextView>(R.id.textAppointmentTime).text = appointment.time ?: "N/A"
            findViewById<ImageView>(R.id.imageDoctor).setImageResource(appointment.profileImage)
        } else {
            Log.e("AppointmentDetailActivity", "Failed to receive appointment object")
            Toast.makeText(this, "Error loading appointment details", Toast.LENGTH_SHORT).show()
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}