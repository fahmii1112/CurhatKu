package com.example.curhatku.ui.informasi

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.curhatku.R
import com.example.curhatku.adapter.ArtikelAdapter
import com.example.curhatku.model.Article

class InformasiFragment : Fragment() {

    private lateinit var listView: ListView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_informasi, container, false)
        listView = view.findViewById(R.id.articleListView)

        val articles = listOf(
            Article("Kesehatan Mental", "Penjelasan singkat tentang kesehatan mental", "api/info/informasi"),
            Article("Ciri-Ciri Kesehatan Mental", "Gejala stres, kecemasan, dan depresi", "api/info/ciri-ciri"),
            Article("Solusi Kesehatan Mental", "Solusi mengatasi stres, kecemasan, dan depresi", "api/info/solusi")
        )


        val adapter = ArtikelAdapter(requireContext(), articles)
        listView.adapter = adapter


        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedArticle = articles[position]


            val bundle = Bundle().apply {
                putString("title", selectedArticle.title) // Judul artikel
                putString("endpoint", selectedArticle.content) // Endpoint API
            }

            findNavController().navigate(R.id.action_informasiFragment_to_detailArtikelFragment, bundle)
        }

        return view
    }
}
