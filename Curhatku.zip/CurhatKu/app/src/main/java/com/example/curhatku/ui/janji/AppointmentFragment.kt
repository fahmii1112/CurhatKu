package com.example.curhatku.ui.janji

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.R
import com.example.curhatku.ui.janji.Detail.AppointmentDetailActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


class AppointmentFragment : Fragment() {

    private lateinit var appointmentsAdapter: AppointmentAdapter
    private val appointmentsList = mutableListOf<Appointment>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_appointment, container, false)

        // Ambil daftar janji dari SharedPreferences
        appointmentsList.addAll(fetchAppointments())

        // Set RecyclerView
        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerViewAppointments)
        recyclerView.layoutManager = LinearLayoutManager(context)
        appointmentsAdapter = AppointmentAdapter(
            appointmentsList,
            onItemClick = { appointment ->
                if (appointment.name.isNullOrEmpty() || appointment.specialty.isNullOrEmpty()) {
                    Log.e("AppointmentFragment", "Invalid appointment data: $appointment")
                    Toast.makeText(requireContext(), "Data janji tidak valid", Toast.LENGTH_SHORT).show()
                    return@AppointmentAdapter
                }

                val intent = Intent(requireContext(), AppointmentDetailActivity::class.java).apply {
                    putExtra("appointment", appointment)
                }
                startActivity(intent)
            },
            onCancelClick = { appointment ->
                appointmentsAdapter.removeAppointment(appointment)
                saveAppointments()
            }
        )
        recyclerView.adapter = appointmentsAdapter // Pastikan adapter diatur

        return view
    }

    private fun saveAppointments() {
        val sharedPreferences = requireContext().getSharedPreferences("Appointments", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(appointmentsList)
        editor.putString("saved_appointments", json)
        editor.apply()
    }

    private fun fetchAppointments(): List<Appointment> {
        val sharedPreferences = requireContext().getSharedPreferences("Appointments", Context.MODE_PRIVATE)
        val gson = Gson()

        val json = sharedPreferences.getString("saved_appointments", "[]")
        val type = object : TypeToken<List<Appointment>>() {}.type
        return gson.fromJson(json, type)
    }
}