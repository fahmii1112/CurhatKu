package com.example.curhatku.model

import com.google.gson.annotations.SerializedName

data class PredictionResponse(

	@field:SerializedName("emotion")
	val emotion: String? = null
)
