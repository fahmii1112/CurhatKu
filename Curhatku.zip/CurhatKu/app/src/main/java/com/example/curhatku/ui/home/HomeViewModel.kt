package com.example.curhatku.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {

    // LiveData untuk data rumah sakit
    private val _hospitalList = MutableLiveData<List<String>>()
    val hospitalList: LiveData<List<String>> get() = _hospitalList

   init {
        // Muat data dummy (atau ganti dengan data dari API)
        loadDummyData()
    }

    private fun loadDummyData() {
        _hospitalList.value = listOf(
            "RS Jiwa Daerah Surakarta",
            "RSJD Dr. Arif Zainudin Surakarta",
            "RS PKU Muhammadiyah Surakarta",
        )
    }
}