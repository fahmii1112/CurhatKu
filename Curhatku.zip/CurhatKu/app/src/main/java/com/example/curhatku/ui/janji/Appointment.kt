package com.example.curhatku.ui.janji

import java.io.Serializable


data class Appointment(
    val name: String,
    val specialty: String,
    val hospitalLocation: String,
    val profileImage: Int,
    val price: String,
    val date: String,
    val time: String
) : Serializable