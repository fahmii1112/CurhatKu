package com.example.curhatku.network

import com.example.curhatku.model.CiriCiriResponse
import com.example.curhatku.model.KesehatanMentalResponse
import com.example.curhatku.model.SolusiResponse
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("api/info/informasi")
    fun getKesehatanMental(): Call<KesehatanMentalResponse>

    @GET("api/info/ciri-ciri")
    fun getCiriCiri(): Call<CiriCiriResponse>

    @GET("api/info/solusi")
    fun getSolusi(): Call<SolusiResponse>

}