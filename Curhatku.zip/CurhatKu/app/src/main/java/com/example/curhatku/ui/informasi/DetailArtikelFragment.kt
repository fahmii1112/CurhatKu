package com.example.curhatku.ui.informasi

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.curhatku.R
import com.example.curhatku.model.CiriCiriResponse
import com.example.curhatku.model.KesehatanMentalResponse
import com.example.curhatku.model.SolusiResponse
import com.example.curhatku.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailArtikelFragment : Fragment() {

    private lateinit var titleTextView: TextView
    private lateinit var updatedDateTextView: TextView
    private lateinit var contentTextView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_detail_artikel, container, false)

        titleTextView = view.findViewById(R.id.articleDetailTitle)
        updatedDateTextView = view.findViewById(R.id.articleDetailLastUpdate)
        contentTextView = view.findViewById(R.id.articleDetailContent)

        val endpoint = arguments?.getString("endpoint")

        fetchDetailFromApi(endpoint ?: "")

        return view
    }

    private fun fetchDetailFromApi(endpoint: String) {
        when (endpoint) {
            "api/info/informasi" -> {
                RetrofitClient.service.getKesehatanMental().enqueue(object :
                    Callback<KesehatanMentalResponse> {
                    override fun onResponse(
                        call: Call<KesehatanMentalResponse>,
                        response: Response<KesehatanMentalResponse>
                    ) {
                        if (response.isSuccessful && response.body() != null) {
                            val detail = response.body()!!
                            titleTextView.text = detail.judul
                            updatedDateTextView.text = detail.tanggal_dipebarui
                            contentTextView.text = detail.isi
                        } else {
                            contentTextView.text = "Gagal memuat konten."
                        }
                    }

                    override fun onFailure(call: Call<KesehatanMentalResponse>, t: Throwable) {
                        contentTextView.text = "Terjadi kesalahan: ${t.message}"
                    }
                })
            }
            "api/info/ciri-ciri" -> {
                RetrofitClient.service.getCiriCiri().enqueue(object : Callback<CiriCiriResponse> {
                    override fun onResponse(
                        call: Call<CiriCiriResponse>,
                        response: Response<CiriCiriResponse>
                    ) {
                        if (response.isSuccessful && response.body() != null) {
                            val detail = response.body()!!
                            titleTextView.text = detail.judul
                            updatedDateTextView.text = "Terakhir Diperbarui: ${detail.tanggal_diperbarui}"

                            val content = """
                                Stres:
                                ${detail.isi.stres}

                                Kecemasan:
                                ${detail.isi.kecemasan}

                                Depresi:
                                ${detail.isi.depresi}
                            """.trimIndent()

                            contentTextView.text = content
                        } else {
                            contentTextView.text = "Gagal memuat konten."
                        }
                    }

                    override fun onFailure(call: Call<CiriCiriResponse>, t: Throwable) {
                        contentTextView.text = "Terjadi kesalahan: ${t.message}"
                    }
                })
            }
            "api/info/solusi" -> {
                RetrofitClient.service.getSolusi().enqueue(object : Callback<SolusiResponse> {
                    override fun onResponse(
                        call: Call<SolusiResponse>,
                        response: Response<SolusiResponse>
                    ) {
                        if (response.isSuccessful && response.body() != null) {
                            val detail = response.body()!!

                            titleTextView.text = detail.judul
                            updatedDateTextView.text = "Terakhir Diperbarui: ${detail.tanggal_diperbarui}"

                            val content = """
                                Stres:
                                ${detail.isi.stres}

                                Kecemasan:
                                ${detail.isi.kecemasan}

                                Depresi:
                                ${detail.isi.depresi}
                            """.trimIndent()

                            contentTextView.text = content
                        } else {
                            contentTextView.text = "Gagal memuat konten."
                        }
                    }

                    override fun onFailure(call: Call<SolusiResponse>, t: Throwable) {
                        contentTextView.text = "Terjadi kesalahan: ${t.message}"
                    }
                })
            }
            else -> {
                contentTextView.text = "Endpoint tidak ditemukan."
            }
        }
    }
}
