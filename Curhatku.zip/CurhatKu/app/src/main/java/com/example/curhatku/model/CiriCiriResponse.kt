package com.example.curhatku.model

data class CiriCiriResponse(
    val judul: String,
    val tanggal_diperbarui: String,
    val isi: IsiCiriCiri
)

data class IsiCiriCiri(
    val stres: String,
    val kecemasan: String,
    val depresi: String
)
