package com.example.curhatku.ui.janji

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.curhatku.R
import com.example.curhatku.databinding.ItemAppointmentBinding

class AppointmentAdapter(
    private val appointments: MutableList<Appointment>, // Gunakan MutableList agar bisa diubah
    private val onItemClick: (Appointment) -> Unit,     // Callback untuk melihat detail janji
    private val onCancelClick: (Appointment) -> Unit    // Callback untuk tombol "Batalkan Janji"
) : RecyclerView.Adapter<AppointmentAdapter.AppointmentViewHolder>() {

    class AppointmentViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val binding = ItemAppointmentBinding.bind(view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppointmentViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_appointment, parent, false)
        return AppointmentViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppointmentViewHolder, position: Int) {
        val appointment = appointments[position]

        holder.binding.apply {
            imageDoctor.setImageResource(appointment.profileImage)
            textDoctorName.text = appointment.name
            textDoctorSpecialty.text = appointment.specialty
            textHospitalLocation.text = appointment.hospitalLocation
            textConsultationPrice.text = appointment.price
            textAppointmentDate.text = appointment.date
            textAppointmentTime.text = appointment.time

            // Tombol "Batalkan Janji"
            buttonMakeAppointment.setOnClickListener {
                onCancelClick(appointment)
            }

            // Klik item untuk melihat detail
            root.setOnClickListener {
                onItemClick(appointment)
            }
        }
    }

    override fun getItemCount(): Int = appointments.size

    // Fungsi untuk menghapus janji
    fun removeAppointment(appointment: Appointment) {
        val position = appointments.indexOf(appointment)
        if (position != -1) {
            appointments.removeAt(position)
            notifyItemRemoved(position)
        }
    }
}