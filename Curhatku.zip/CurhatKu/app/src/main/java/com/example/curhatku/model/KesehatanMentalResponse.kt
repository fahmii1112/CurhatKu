package com.example.curhatku.model

data class KesehatanMentalResponse(
    val judul: String,
    val tanggal_dipebarui: String,
    val isi: String
)